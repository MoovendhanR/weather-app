
import './App.css';
import WeatherComponent from './Components/Weathercomponent';

function App() {
  
  return (
   <div className="fullImage">

    <div className="App">
           <WeatherComponent/>
    </div>
   </div>
  );
}

export default App;
